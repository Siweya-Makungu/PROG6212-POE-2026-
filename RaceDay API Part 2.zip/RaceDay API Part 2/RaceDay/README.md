# RaceDay — PROG6212 POE Part 2

ASP.NET Core 8 Web API for South African running, walking and cycling events, based on the submitted RaceDay Part 1 endpoint plan.

## Requirements
- Visual Studio 2022 (17.8 or later), **ASP.NET and web development** workload, .NET 8 SDK
- SQL Server LocalDB (Visual Studio installer) or SQL Server Express
- Internet access for the first NuGet package restore

## Open and run in Visual Studio
1. Unzip and open **RaceDay.sln**.
2. In **RaceDay.Api**, set your SQL Server connection string in `appsettings.json`. Default is `(localdb)\MSSQLLocalDB` (Windows).
3. Configure a **private JWT signing key**. In Visual Studio right-click `RaceDay.Api` → **Manage User Secrets** and add `{"Jwt":{"Key":"replace-with-a-private-random-key-of-at-least-32-characters"}}`. Alternatively set environment variable `Jwt__Key`. Never commit a real key.
4. Open **Tools → NuGet Package Manager → Package Manager Console**, select `RaceDay.Api` as default project. Run `Add-Migration InitialCreate` then `Update-Database`. If `Add-Migration` is not recognised, install `dotnet-ef` using `dotnet tool restore` inside `RaceDay.Api` and use the CLI commands below.
5. Set **RaceDay.Api** as startup project and press **F5**. Swagger opens at `https://localhost:7043/swagger` (your local port may vary).
6. Register an Organiser and a Participant via `/api/auth/register`. Log in with `/api/auth/login`, copy `token`, click **Authorize** in Swagger and paste the token. Test protected endpoints.
7. In **Test → Test Explorer**, run all tests from `RaceDay.Tests`.

## CLI setup (from project root)
```powershell
dotnet restore RaceDay.sln
dotnet tool restore --tool-manifest RaceDay.Api/.config/dotnet-tools.json
dotnet ef migrations add InitialCreate --project RaceDay.Api --startup-project RaceDay.Api
dotnet ef database update --project RaceDay.Api --startup-project RaceDay.Api
dotnet test RaceDay.sln
dotnet run --project RaceDay.Api --launch-profile https
```
For the EF CLI commands, the tool manifest is inside `RaceDay.Api`; run them from that folder (`dotnet tool run dotnet-ef -- migrations add InitialCreate`, then `... database update`) or install `dotnet-ef` globally. The Package Manager Console commands are easiest in Visual Studio.

## API routes
| Method | Route | Access |
|---|---|---|
| POST | `/api/auth/register` | Public |
| POST | `/api/auth/login` | Public |
| GET/PUT | `/api/users/me` | Authenticated |
| GET | `/api/events`, `/api/events/{id}` | Public |
| POST | `/api/events` | Organiser |
| PUT/DELETE | `/api/events/{id}` | Event owner Organiser |
| GET | `/api/events/{id}/categories` | Public |
| POST/PUT/DELETE | `/api/events/{id}/categories[/{categoryId}]` | Event owner Organiser |
| POST | `/api/enrollments` | Participant |
| GET | `/api/enrollments/me` | Participant |
| GET | `/api/events/{id}/enrollments` | Event owner Organiser |
| POST | `/api/results` | Event owner Organiser |
| GET | `/api/events/{id}/results` | Public |

### Example request bodies
Register: `{"firstName":"Thabo","lastName":"Mokoena","email":"thabo@example.com","password":"StrongPass123!","role":"Organiser"}`

Create event: `{"eventName":"Soweto Fun Run","description":"Community 10 km","eventDate":"2026-12-05T07:00:00","location":"Soweto"}`

Add category: `{"name":"10 km","distanceKm":10}`

Enrol: `{"categoryId":1}`

Record result: `{"enrollmentId":1,"finishTime":"00:48:12","position":1,"pace":4.82}`

## Important design notes
- Uses JWT bearer authentication to maintain authenticated requests without storing a server-side session; the role claim controls API permissions. Passwords are hashed using ASP.NET Core PasswordHasher.
- Organisers can only modify their own events/categories and record results for their own events. Participants can only enrol and view their own entries.
- `Database/initial-schema.sql` is an illustrative standalone SQL Server create script. **Choose either EF Core migrations or this script for initial schema creation, not both.** EF migrations are recommended.
- The schema uses `RaceEvent` to avoid clashing with .NET event syntax; the public endpoint remains `/api/events`.
- The supplied Part 1 plan does not specify category update/delete endpoints, so they were added to satisfy Part 2 requirements.
- Swagger provides descriptions through XML comments.
- The automated tests use EF Core's in-memory provider for controller behaviour. They do not replace SQL Server integration tests or a complete deployed API smoke test.
- For a production deployment, add email verification, refresh/revocation tokens, rate limiting, stronger registration approval for Organiser roles, audit logging, and production secret management. Public self-registration as Organiser follows the assignment but is not suitable for production without verification.

## Verification status
Source files and solution structure are included. The authoring environment did **not** have the .NET SDK installed, so `dotnet build`, `dotnet test` and live SQL Server/Swagger execution could not be performed here. Run them in Visual Studio and resolve any environment-specific issues before submission.
